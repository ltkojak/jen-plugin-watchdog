"""
Host Watchdog plugin for Jen.
Probes chosen hosts on a schedule and alerts when one stops answering,
and again when it comes back. Network Discovery alerts when an unknown
host appears; nothing alerts when a KNOWN host disappears — this fills
that gap.
Version lives in manifest.json — not duplicated here.

Probing (v1.0.0)
─────────────────
`ping` targets use `ping -c 1 -W 1 <ip>` as list-args — Ubuntu's
/usr/bin/ping carries cap_net_raw, so this works unprivileged the same
way Network Discovery's neighbour-table read does. `tcp:<port>[,<port>]`
targets try each port in order with a 2s connect timeout; any one
succeeding counts as up. Every due target is probed through one
module-level 8-thread pool, one run at a time (a lock, like Discovery's
_scan_lock), budgeted at 30s total per periodic tick — a run that runs
long just leaves the stragglers for the next tick rather than blocking
it.

State machine (v1.0.0, pure — see next_state())
─────────────────────────────────────────────────
A target starts 'unknown'. Any single successful probe moves it (or
keeps it) 'up'. A run of `fails_to_down` CONSECUTIVE failures moves it
to 'down' — a lone blip while 'up' or 'unknown' does not flip it early.
Once 'down', it only leaves on the next success. Transitions (not
every check) send an alert and emit an event — except the very first
result of a new target: 'unknown' -> 'up' is the plugin learning where
the target is, not a host coming back, so it is recorded silently
(see should_alert()).

Who may see and change what (v1.0.2)
─────────────────────────────────────
A target belongs to the subnet its IP is in (`derive_subnet_id`), stored
in `wd_targets.subnet_id`, or to no subnet at all. Every route judges
THAT stored value — the page, the history, pause/resume, delete — and
"no subnet" is for unrestricted callers only, for API keys too. A value
the caller typed (a `subnet_id` query parameter) is never the subject of
a decision: `watch_from_row` derives the subnet from the address itself.
Every decision goes through `plugin_api.can_access_subnet` /
`api_key_can_access_subnet`, so "None" means the same thing here as in
Jen's own pages.
"""

import ipaddress
import logging
import os as _os
import re
import socket
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FuturesTimeoutError
from datetime import datetime, timedelta, timezone

from flask import Blueprint, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from jen.plugin_api import is_admin_or_above, require_write

logger = logging.getLogger(__name__)

PLUGIN_ID = "watchdog"

bp = Blueprint(
    "watchdog",
    __name__,
    template_folder="templates",
    root_path=_os.path.dirname(_os.path.abspath(__file__)),
    url_prefix="/network/watchdog",
)

_PROBE_CHOICES = ("ping", "tcp")
_SOURCES = ("reservation", "ipam", "manual")
_INTERVAL_CHOICES = (1, 5, 15, 30, 60)
_FAILS_CHOICES = (1, 2, 3, 5, 10)

# wd_targets.probe is VARCHAR(40) (migration 1): a longer probe string would fail the INSERT, so
# parse_probe() refuses it first with a sentence that says why.
_PROBE_MAX_LEN = 40

_VIEWER_MESSAGE = "Viewers can look at Watchdog but not change it."

# Probing.
_PING_TIMEOUT_S = 3
_TCP_CONNECT_TIMEOUT_S = 2
_POOL_WORKERS = 8
_RUN_BUDGET_S = 30

# History retention.
_KEEP_CHECKS_DAYS = 7
_HISTORY_LIMIT = 50

_PING_RTT_RE = re.compile(r"time=([\d.]+)\s*ms")
_TCP_PROBE_RE = re.compile(r"^tcp:(\d{1,5}(?:,\d{1,5})*)$")

_run_lock = threading.Lock()
_pool = ThreadPoolExecutor(max_workers=_POOL_WORKERS, thread_name_prefix="wd-probe")


# ── Pure: probe strings, ping output, the state machine, due targets, uptime ──


def parse_probe(probe):
    """Pure: ('ping', None) | ('tcp', [ports]) | (None, error message).
    Each port must be 1-65535; 'tcp:80,443' probes both in order."""
    probe = (probe or "").strip()
    if probe == "ping":
        return "ping", None
    m = _TCP_PROBE_RE.match(probe)
    if not m:
        return None, f"Unknown probe {probe!r} — use 'ping' or 'tcp:<port>[,<port>]'."
    ports = [int(p) for p in m.group(1).split(",")]
    bad = [p for p in ports if not (1 <= p <= 65535)]
    if bad:
        return None, f"Invalid port(s): {bad}"
    if len(probe) > _PROBE_MAX_LEN:
        return (
            None,
            f"That probe is {len(probe)} characters long and a probe holds at most {_PROBE_MAX_LEN} - list fewer ports.",
        )
    return "tcp", ports


def parse_ping(returncode, stdout):
    """Pure: (ok, rtt_ms) from `ping -c 1`'s exit code and stdout. rtt_ms
    is None when there's no reply line to parse (unreachable/timeout)."""
    ok = returncode == 0
    m = _PING_RTT_RE.search(stdout or "")
    rtt = float(m.group(1)) if m else None
    return ok, rtt


def next_state(state, consecutive_fails, fails_to_down, ok):
    """Pure: (new_state, new_consecutive_fails, transitioned). A single
    success always recovers to 'up' from anywhere. A failure only flips
    'up' or 'unknown' to 'down' once `fails_to_down` consecutive
    failures have been seen — a lone blip doesn't flip it early;
    'down' simply stays 'down' (its fail count keeps climbing but that
    never fires a second alert — the caller only alerts on a
    transition)."""
    if ok:
        return "up", 0, (state != "up")
    fails = consecutive_fails + 1
    if fails >= fails_to_down and state != "down":
        return "down", fails, True
    return state, fails, False


def should_alert(previous_state, new_state, transitioned):
    """Pure: does this transition deserve an alert (and a Timeline event)?
    Every transition does, except a target's first result being 'up' —
    `next_state` reports unknown -> up as a transition, and a new target
    answering its first probe is not "answering again"."""
    if not transitioned:
        return False
    return not (previous_state == "unknown" and new_state == "up")


def due_targets(targets, last_checked, now):
    """Pure: ids of `targets` (each {id, interval_min, enabled}) whose
    last check (from `last_checked`, {id: datetime or None}) is at
    least interval_min old, or that have never been checked."""
    due = []
    for t in targets:
        if not t.get("enabled"):
            continue
        last = last_checked.get(t["id"])
        if last is None or (now - last) >= timedelta(minutes=t["interval_min"]):
            due.append(t["id"])
    return due


def uptime_pct(checks):
    """Pure: rounded % of `checks` ({"ok": bool}, any window) that were
    ok, or None when the window has no checks at all."""
    if not checks:
        return None
    return round(sum(1 for c in checks if c["ok"]) / len(checks) * 100)


def derive_subnet_id(ip, subnet_map):
    """Pure: the Kea subnet id (from `subnet_map`, {id: {"cidr": ...}})
    whose CIDR contains `ip`, or None when no accessible subnet does —
    a target on an address in no Kea subnet at all, per the Q55 rule
    IPAM's unmanaged subnets already use."""
    try:
        addr = ipaddress.IPv4Address(ip)
    except ValueError:
        return None
    for sid, info in subnet_map.items():
        try:
            if addr in ipaddress.IPv4Network(info["cidr"], strict=False):
                return sid
        except ValueError:
            continue
    return None


def _format_identifier(hex_str, ident_type):
    """Format a Kea host identifier for display. Only type 0 (hw-address) is a MAC."""
    if not hex_str:
        return ""
    if ident_type == 0 and len(hex_str) == 12:
        return ":".join(hex_str[i : i + 2] for i in range(0, 12, 2)).lower()
    return f"id:{hex_str.lower()}"


# ── DB helpers ────────────────────────────────────────────────────────────────


def _get_db():
    from jen.plugin_api import get_jen_db

    return get_jen_db()


def _get_kea_db():
    from jen.plugin_api import get_kea_db

    return get_kea_db()


def _subnet_map():
    from jen.plugin_api import subnet_map

    return subnet_map()


def _can(subnet_id):
    """May the session user act on something in `subnet_id`? `None` (no Kea subnet
    contains the address) is for unrestricted users only — plugin_api decides."""
    from jen.plugin_api import can_access_subnet

    return can_access_subnet(subnet_id)


def _visible_rows(rows):
    """Filters DB rows carrying a `subnet_id` column to the caller's subnets; a NULL
    subnet_id (no Kea subnet contains the target's IP) is unrestricted-only."""
    return [r for r in rows if _can(r.get("subnet_id"))]


def _load_target(target_id):
    """(row, refusal): the wd_targets row the caller may act on, else (None, why).
    A target in a subnet the caller cannot see is reported exactly as one that does
    not exist — the by-id routes must not confirm what is out of the caller's sight.

    v1.0.4 — a DB failure here used to propagate uncaught (only the `finally` closed the
    connection): toggle, delete and history all turned it into a 500 page instead of the same
    generic refusal every other write route already gives a database error."""
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute("SELECT id, subnet_id, enabled FROM wd_targets WHERE id=%s", (target_id,))
            row = cur.fetchone()
    except Exception as e:
        logger.error(f"Watchdog: could not load target {target_id}: {e}")
        return None, "Could not load the target; the details are in Jen's log."
    finally:
        if db:
            db.close()
    if row is None or not _can(row["subnet_id"]):
        return None, "Target not found."
    return row, ""


def _normalize_mac(raw):
    """'' for no MAC given, the lowercase MAC for a valid one, '' for garbled input too (Watchdog's own
    convention: unlike IPAM, a bad MAC here has never been treated as a hard error — see add_target/
    watch_from_row, which just drop it). Delegates the actual parsing to plugin_api's normalize_mac()."""
    if not raw:
        return ""
    from jen.plugin_api import normalize_mac

    return normalize_mac(raw) or ""


def _audit(action, target, detail):
    try:
        from jen.plugin_api import audit

        audit(action, target, detail)
    except Exception as e:
        logger.error(f"Watchdog: audit failed: {e}")


# ── Candidates for the Add Target picker ───────────────────────────────────────


def _candidate_hosts():
    """Reservations (Kea's hosts table, incl. global ones) plus IPAM
    Lite static/planned entries, across the caller's subnets only. A global
    reservation belongs to no subnet, so it is offered to unrestricted callers
    alone — a scoped admin would otherwise be handed hosts from every subnet."""
    out = []
    kdb = None
    try:
        kdb = _get_kea_db()
        with kdb.cursor() as cur:
            cur.execute(
                "SELECT inet_ntoa(ipv4_address) AS ip, hostname, HEX(dhcp_identifier) AS ident_hex, "
                "dhcp_identifier_type AS ident_type, dhcp4_subnet_id AS subnet_id FROM hosts "
                "WHERE ipv4_address IS NOT NULL AND ipv4_address > 0"
            )
            for row in cur.fetchall():
                if not row["ip"]:
                    continue
                sid = row.get("subnet_id") or None
                if not _can(sid):
                    continue
                mac = _format_identifier(row.get("ident_hex"), row.get("ident_type"))
                out.append(
                    {
                        "ip": row["ip"],
                        "mac": mac if not mac.startswith("id:") else "",
                        "label": row.get("hostname") or "",
                        "subnet_id": sid,
                        "source": "reservation",
                    }
                )
    except Exception as e:
        logger.warning(f"Watchdog: reservation candidates failed: {e}")
    finally:
        if kdb:
            kdb.close()
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                "SELECT ip, mac, label, subnet_id FROM ipam_static_entries "
                "WHERE subnet_kind='kea' AND entry_status IN ('static','planned')"
            )
            for row in cur.fetchall():
                if not _can(row["subnet_id"]):
                    continue
                out.append(
                    {
                        "ip": row["ip"],
                        "mac": row.get("mac") or "",
                        "label": row.get("label") or "",
                        "subnet_id": row["subnet_id"],
                        "source": "ipam",
                    }
                )
    except Exception:
        pass  # IPAM Lite not installed, or its table not yet migrated
    finally:
        if db:
            db.close()
    return out


# ── Probing (impure: subprocess / socket) ──────────────────────────────────────


def _probe_target(target):
    """One target's probe -> (ok, rtt_ms, error)."""
    kind, spec = parse_probe(target["probe"])
    if kind == "ping":
        try:
            proc = subprocess.run(
                ["ping", "-c", "1", "-W", "1", target["ip"]],
                capture_output=True,
                text=True,
                timeout=_PING_TIMEOUT_S,
            )
            ok, rtt = parse_ping(proc.returncode, proc.stdout)
            return ok, rtt, "" if ok else "no reply"
        except Exception as e:
            return False, None, str(e)[:200]
    if kind == "tcp":
        last_err = ""
        for port in spec:
            try:
                start = time.monotonic()
                with socket.create_connection((target["ip"], port), timeout=_TCP_CONNECT_TIMEOUT_S):
                    return True, round((time.monotonic() - start) * 1000), ""
            except Exception as e:
                last_err = str(e)[:150]
                continue
        return False, None, f"no response on port(s) {','.join(str(p) for p in spec)}: {last_err}"
    return False, None, "invalid probe configuration"


def _tick():
    """The periodic job (every PERIODIC_MIN_MINUTES, Jen's own floor —
    5 as of v5.57.0-5.60.x): probe every due, enabled target through
    the module pool, one run at a time. Records a wd_checks row and
    updates wd_state per target; alerts + emits only
    on a state transition. Prunes wd_checks older than 7 days."""
    if not _run_lock.acquire(blocking=False):
        return
    try:
        db = None
        try:
            db = _get_db()
            with db.cursor() as cur:
                cur.execute(
                    "SELECT id, ip, probe, interval_min, fails_to_down, label, subnet_id, mac, enabled "
                    "FROM wd_targets WHERE enabled=1"
                )
                targets = cur.fetchall()
                cur.execute("SELECT target_id, MAX(checked_at) AS last FROM wd_checks GROUP BY target_id")
                last_checked = {r["target_id"]: r["last"] for r in cur.fetchall()}
        finally:
            if db:
                db.close()
        if not targets:
            return
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        due_ids = set(due_targets(targets, last_checked, now))
        due = [t for t in targets if t["id"] in due_ids]
        if not due:
            return

        deadline = time.monotonic() + _RUN_BUDGET_S
        futures = {_pool.submit(_probe_target, t): t for t in due}
        results = {}
        try:
            for fut in as_completed(futures, timeout=max(0.1, deadline - time.monotonic())):
                t = futures[fut]
                try:
                    results[t["id"]] = fut.result()
                except Exception as e:
                    results[t["id"]] = (False, None, str(e)[:200])
        except FuturesTimeoutError:
            pass  # whatever finished in budget gets recorded; stragglers wait for the next tick

        _record_results({t["id"]: t for t in due}, results)
    finally:
        _run_lock.release()


def _record_results(by_id, results):
    if not results:
        return
    db = None
    to_alert = []  # v1.0.4 — collected here, sent after commit/close: see below
    committed = False
    try:
        db = _get_db()
        with db.cursor() as cur:
            for target_id, (ok, rtt, error) in results.items():
                cur.execute(
                    "INSERT INTO wd_checks (target_id, checked_at, ok, rtt_ms, error) "
                    "VALUES (%s, UTC_TIMESTAMP(), %s, %s, %s)",
                    (target_id, 1 if ok else 0, rtt, (error or "")[:200]),
                )
                cur.execute(
                    "SELECT state, consecutive_fails FROM wd_state WHERE target_id=%s",
                    (target_id,),
                )
                row = cur.fetchone()
                state = row["state"] if row else "unknown"
                fails = row["consecutive_fails"] if row else 0
                target = by_id[target_id]
                new_state, new_fails, transitioned = next_state(state, fails, target["fails_to_down"], ok)
                if row:
                    cur.execute(
                        "UPDATE wd_state SET state=%s, consecutive_fails=%s, "
                        "last_ok_at=IF(%s, UTC_TIMESTAMP(), last_ok_at), "
                        "last_fail_at=IF(%s, last_fail_at, UTC_TIMESTAMP()), "
                        "last_error=%s, since=IF(%s, UTC_TIMESTAMP(), since) WHERE target_id=%s",
                        (new_state, new_fails, ok, ok, (error or "")[:200], transitioned, target_id),
                    )
                else:
                    cur.execute(
                        "INSERT INTO wd_state (target_id, state, consecutive_fails, since, last_ok_at, "
                        "last_fail_at, last_error) VALUES (%s, %s, %s, UTC_TIMESTAMP(), "
                        "IF(%s, UTC_TIMESTAMP(), NULL), IF(%s, NULL, UTC_TIMESTAMP()), %s)",
                        (target_id, new_state, new_fails, ok, ok, (error or "")[:200]),
                    )
                if should_alert(state, new_state, transitioned):
                    to_alert.append((target, new_state))
            cur.execute(
                "DELETE FROM wd_checks WHERE checked_at < UTC_TIMESTAMP() - INTERVAL %s DAY", (_KEEP_CHECKS_DAYS,)
            )
        db.commit()
        committed = True
    except Exception as e:
        logger.error(f"Watchdog: recording results failed: {e}")
        if db:
            try:
                db.rollback()  # nothing of this tick is stored; the pool would reset the connection anyway
            except Exception as rollback_error:
                logger.warning(f"Watchdog: could not roll back the failed recording: {rollback_error}")
    finally:
        if db:
            db.close()
    # v1.1.2 - an alert is sent only for a transition that was STORED. The loop above fills to_alert from inside the
    # same try that does the INSERTs, and this loop used to run after the `finally` whatever happened, so a later
    # INSERT that failed rolled the state back and the alerts for the targets before it were still sent: an alert for
    # a state that was never recorded, sent a second time by the next tick, which finds the same transition again.
    # Now nothing is sent unless db.commit() returned; the next tick detects the transition and sends it once.
    if not committed:
        return
    # v1.0.4 — sending an alert (send_alert/emit) is network/DB I/O of its own; doing it INSIDE the open
    # cursor loop above held the whole tick's transaction/connection open for as long as every alert took
    # to send. Collected during the loop, sent only after the connection that recorded them is closed.
    for target, new_state in to_alert:
        _alert_transition(target, new_state)


# v1.1.1 - ONE refusal for an address the caller may not add: 1.1.0 had two sentences, one for an address in a Kea subnet the caller
# cannot see and one for an address in no Kea subnet, so a scoped admin could probe which addresses are inside ANY Kea subnet.
ADDRESS_REFUSAL = "That address is not in a subnet you can access."


def _alert_transition(target, new_state):
    alert_type = "watchdog_down" if new_state == "down" else "watchdog_up"
    label = target.get("label") or target["ip"]
    subnet_name = _subnet_map().get(target.get("subnet_id"), {}).get("name", "") if target.get("subnet_id") else ""
    try:
        from jen.plugin_api import send_alert

        # v1.1.1 - a target in no Kea subnet has no subnet to scope the alert by. Without `scoped=True` such an alert went to EVERY
        # channel, a subnet-scoped one included (the scope reads "no subnet" as "not about a subnet"); with it only a channel that
        # has no subnet scope receives it, which is what the operator who limited a channel to some subnets asked for. A target
        # that has a subnet is sent exactly as before.
        extra = {"scoped": True} if target.get("subnet_id") is None else {}
        send_alert(
            alert_type,
            subnet_id=target.get("subnet_id"),
            label=label,
            ip=target["ip"],
            subnet=subnet_name or "no Kea subnet",
            **extra,
        )
    except Exception as e:
        logger.warning(f"Watchdog: could not send {alert_type} alert: {e}")
    try:
        from jen.plugin_api import emit

        emit(
            f"plugin.watchdog.{'down' if new_state == 'down' else 'up'}",
            mac=target.get("mac") or None,
            ip=target["ip"],
            subnet_id=target.get("subnet_id"),
            detail=f"{label} is {new_state}",
        )
    except Exception as e:
        logger.warning(f"Watchdog: could not emit transition event: {e}")


# ── Search provider (register_search_provider) ────────────────────────────────


def _watchdog_search(query, accessible_subnet_ids, all_subnets):
    q = (query or "").strip()
    if not q:
        return []
    from jen.plugin_api import like_pattern, search_scope

    # v1.0.4 — the caller's own subnet scope is now IN the query, before its own LIMIT 20; a NULL
    # t.subnet_id (a target in no Kea subnet) is excluded for a restricted caller by ordinary SQL NULL
    # semantics (`NULL IN (...)` is never true), matching the unrestricted-only rule everywhere else.
    scope = search_scope(accessible_subnet_ids, all_subnets, "t.subnet_id")
    if scope is None:
        return []
    scope_clause, scope_params = scope
    like = like_pattern(q)
    out = []
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                f"SELECT t.id, t.ip, t.label, t.subnet_id, s.state FROM wd_targets t "
                f"LEFT JOIN wd_state s ON s.target_id = t.id "
                f"WHERE {scope_clause} AND (t.label LIKE %s OR t.ip LIKE %s) ORDER BY t.created_at DESC LIMIT 20",  # nosec B608 - scope_clause is search_scope()'s own %s placeholders, values bound below
                (*scope_params, like, like),
            )
            for row in cur.fetchall():
                out.append(
                    {
                        "title": row.get("label") or row["ip"],
                        "subtitle": f"{row['ip']} · {row.get('state') or 'unknown'}",
                        "href": url_for("watchdog.index"),
                        "subnet_id": row["subnet_id"],
                    }
                )
    except Exception as e:
        logger.error(f"Watchdog: search provider failed: {e}")
    finally:
        if db:
            db.close()
    return out


# ── Investigation provider (v1.1.0, Jen 5.68.0) ──────────────────────────────

_INVESTIGATION_MAX_TARGETS = 5


def _when(value):
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d %H:%M UTC")
    return str(value) if value else ""


def subject_addresses(subject):
    """Pure: the IPv4 addresses this client is known by - the one the page was opened on, its active leases and its
    reservations - each validated, de-duplicated and capped. A watchdog target is an address, so this is what finds it."""
    seen = []
    candidates = [getattr(subject, "ip", "")]
    candidates += [row.get("ip") for row in (getattr(subject, "leases4", None) or []) if isinstance(row, dict)]
    candidates += [row.get("ip") for row in (getattr(subject, "reservations", None) or []) if isinstance(row, dict)]
    for raw in candidates:
        try:
            addr = str(ipaddress.IPv4Address(str(raw).strip()))
        except ValueError:
            continue
        if addr not in seen:
            seen.append(addr)
    return seen[:6]


def _target_line(t):
    name = t.get("label") or t.get("ip")
    state = t.get("state") or "unknown"
    if not t.get("enabled", 1):
        return f"{name} is paused"
    if state == "down":
        fails = t.get("consecutive_fails") or 0
        since = f" since {_when(t['since'])}" if t.get("since") else ""
        return f"{name} is down{since} ({fails} failed check{'s' if fails != 1 else ''} in a row)"
    if state == "up":
        return f"{name} is answering" + (f" (up since {_when(t['since'])})" if t.get("since") else "")
    return f"{name} has no result yet"


def investigation_card(targets):
    """Pure: the Investigation page's card from the watchdog targets that match this client (its MAC or any of its
    addresses), or None when there are none. A target that is down makes it a warn card - the one sentence then also joins
    the page's one-line answer - and down targets are listed first."""
    if not targets:
        return None
    order = {"down": 0, "unknown": 1, "up": 2}
    shown = sorted(
        targets, key=lambda t: (order.get(t.get("state") or "unknown", 1), t.get("label") or t.get("ip") or "")
    )
    shown = shown[:_INVESTIGATION_MAX_TARGETS]
    rows = []
    for t in shown:
        state = t.get("state") or "unknown"
        rows.append(
            {
                "label": t.get("label") or t["ip"],
                "value": f"{t['ip']} - {state}" + (" (paused)" if not t.get("enabled", 1) else ""),
            }
        )
        if t.get("last_ok_at"):
            rows.append({"label": "Last answered", "value": _when(t["last_ok_at"])})
        if state == "down" and t.get("last_fail_at"):
            rows.append({"label": "Last failed", "value": _when(t["last_fail_at"])})
        if state == "down" and t.get("last_error"):
            rows.append({"label": "Last error", "value": str(t["last_error"])})
        rows.append({"label": "Probe", "value": t.get("probe") or "ping"})
    down = any((t.get("state") == "down") and t.get("enabled", 1) for t in shown)
    return {"summary": "; ".join(_target_line(t) for t in shown), "status": "warn" if down else "ok", "rows": rows}


def _targets_for_client(mac, addresses, accessible_subnet_ids, all_subnets):
    """The targets whose stored MAC or address is this client's, inside the caller's own subnet scope - in the query,
    before its LIMIT. A target in no Kea subnet is for an unrestricted caller only (a NULL never matches `IN (...)`)."""
    from jen.plugin_api import in_placeholders, search_scope

    scope = search_scope(accessible_subnet_ids, all_subnets, "t.subnet_id")
    if scope is None:
        return []
    scope_clause, scope_params = scope
    identity, identity_params = [], []
    if mac:
        identity.append("t.mac=%s")
        identity_params.append(mac)
    if addresses:
        identity.append(f"t.ip IN ({in_placeholders(addresses)})")
        identity_params.extend(addresses)
    if not identity:
        return []
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                f"SELECT t.id, t.ip, t.mac, t.label, t.subnet_id, t.probe, t.enabled, s.state, s.since, s.last_ok_at, "
                f"s.last_fail_at, s.consecutive_fails, s.last_error FROM wd_targets t "
                f"LEFT JOIN wd_state s ON s.target_id = t.id "
                f"WHERE {scope_clause} AND ({' OR '.join(identity)}) ORDER BY t.label, t.ip LIMIT {_INVESTIGATION_MAX_TARGETS}",  # nosec B608 - scope_clause and the identity terms are fixed fragments with %s placeholders; every value is bound below
                (*scope_params, *identity_params),
            )
            return list(cur.fetchall())
    finally:
        if db:
            db.close()


def _investigate(subject, accessible_subnet_ids, all_subnets):
    """The Investigation page's card for the client Jen resolved: the watchdog targets on its MAC or its addresses. Each
    target is judged on its OWN stored subnet, in the query, so a restricted caller never gets one from a subnet outside
    the set they were given."""
    mac = _normalize_mac(getattr(subject, "mac", "") or "")
    card = investigation_card(_targets_for_client(mac, subject_addresses(subject), accessible_subnet_ids, all_subnets))
    if card is not None:
        card["href"] = "/network/watchdog"
    return card


# ── Routes: page ────────────────────────────────────────────────────────────


def _target_rows():
    """v1.0.4 — the 7-day uptime used to be one `wd_checks` query PER TARGET (N+1: an index page with
    thirty targets ran thirty-one queries). One query for every target's checks, grouped in Python —
    `wd_checks` is already indexed on (target_id, checked_at) for exactly this window."""
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                "SELECT t.id, t.ip, t.mac, t.label, t.subnet_id, t.source, t.probe, t.interval_min, "
                "t.fails_to_down, t.enabled, s.state, s.since, s.last_ok_at, s.last_error "
                "FROM wd_targets t LEFT JOIN wd_state s ON s.target_id = t.id ORDER BY t.label, t.ip"
            )
            rows = cur.fetchall()
            cur.execute("SELECT target_id, ok FROM wd_checks WHERE checked_at >= UTC_TIMESTAMP() - INTERVAL 7 DAY")
            by_target = {}
            for c in cur.fetchall():
                by_target.setdefault(c["target_id"], []).append({"ok": bool(c["ok"])})
            for r in rows:
                r["uptime_pct"] = uptime_pct(by_target.get(r["id"], []))
    except Exception as e:
        logger.error(f"Watchdog: index error: {e}")
        rows = []
    finally:
        if db:
            db.close()
    return rows


@bp.route("/")
@login_required
def index():
    rows = _visible_rows(_target_rows())
    subnet_map = _subnet_map()
    for r in rows:
        r["subnet_name"] = subnet_map.get(r["subnet_id"], {}).get("name", "") if r["subnet_id"] else "—"
    admin = is_admin_or_above()
    candidates = _candidate_hosts() if admin else []
    return render_template(
        "watchdog/index.html",
        rows=rows,
        candidates=candidates,
        interval_choices=_INTERVAL_CHOICES,
        fails_choices=_FAILS_CHOICES,
        is_admin=admin,
    )


@bp.route("/targets/add", methods=["POST"])
@login_required
@require_write(_VIEWER_MESSAGE, "watchdog.index")
def add_target():
    ip = request.form.get("ip", "").strip()
    try:
        ipaddress.IPv4Address(ip)
    except ValueError:
        flash("Invalid IP address.", "error")
        return redirect(url_for("watchdog.index"))

    label = request.form.get("label", "").strip()[:100]
    mac = _normalize_mac(request.form.get("mac", ""))
    source = request.form.get("source", "manual")
    if source not in _SOURCES:
        source = "manual"
    probe = request.form.get("probe", "ping").strip()
    kind, err = parse_probe(probe)
    if kind is None:
        flash(err, "error")
        return redirect(url_for("watchdog.index"))
    try:
        interval_min = int(request.form.get("interval_min", 5))
        fails_to_down = int(request.form.get("fails_to_down", 3))
    except ValueError:
        flash("Invalid interval or failure threshold.", "error")
        return redirect(url_for("watchdog.index"))
    if interval_min not in _INTERVAL_CHOICES or fails_to_down not in _FAILS_CHOICES:
        flash("Pick one of the offered interval/threshold values.", "error")
        return redirect(url_for("watchdog.index"))

    subnet_id = derive_subnet_id(ip, _subnet_map())
    if not _can(subnet_id):
        flash(ADDRESS_REFUSAL, "error")
        return redirect(url_for("watchdog.index"))

    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            # v1.0.4 — watch_from_row already refused a second target for one IP; add_target (the
            # page's own "Add Target" form) did not, so two identical targets could both probe and
            # alert for the same host.
            cur.execute("SELECT id FROM wd_targets WHERE ip=%s", (ip,))
            if cur.fetchone():
                flash(f"{label or ip} is already being watched.", "warning")
                return redirect(url_for("watchdog.index"))
            cur.execute(
                "INSERT INTO wd_targets (ip, mac, subnet_id, label, source, probe, interval_min, "
                "fails_to_down, created_by) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (ip, mac or None, subnet_id, label, source, probe, interval_min, fails_to_down, current_user.username),
            )
        db.commit()
        flash(f"Now watching {label or ip}.", "success")
        _audit("WATCHDOG_ADD", ip, f"label={label} probe={probe}")
    except Exception as e:
        logger.error(f"Watchdog: could not add target: {e}")
        flash("Could not add target; the details are in Jen's log.", "error")
    finally:
        if db:
            db.close()
    return redirect(url_for("watchdog.index"))


@bp.route("/targets/<int:target_id>/toggle", methods=["POST"])
@login_required
@require_write(_VIEWER_MESSAGE, "watchdog.index")
def toggle_target(target_id):
    row, refusal = _load_target(target_id)
    if row is None:
        flash(refusal, "error")
        return redirect(url_for("watchdog.index"))
    new_enabled = 0 if row["enabled"] else 1
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute("UPDATE wd_targets SET enabled=%s WHERE id=%s", (new_enabled, target_id))
        db.commit()
        flash("Target resumed." if new_enabled else "Target paused.", "success")
    except Exception as e:
        logger.error(f"Watchdog: could not update target: {e}")
        flash("Could not update target; the details are in Jen's log.", "error")
    finally:
        if db:
            db.close()
    return redirect(url_for("watchdog.index"))


@bp.route("/targets/<int:target_id>/delete", methods=["POST"])
@login_required
@require_write(_VIEWER_MESSAGE, "watchdog.index")
def delete_target(target_id):
    row, refusal = _load_target(target_id)
    if row is None:
        flash(refusal, "error")
        return redirect(url_for("watchdog.index"))
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute("DELETE FROM wd_checks WHERE target_id=%s", (target_id,))
            cur.execute("DELETE FROM wd_state WHERE target_id=%s", (target_id,))
            cur.execute("DELETE FROM wd_targets WHERE id=%s", (target_id,))
        db.commit()
        flash("Target removed.", "success")
        _audit("WATCHDOG_DELETE", str(target_id), "target removed")
    except Exception as e:
        logger.error(f"Watchdog: could not remove target: {e}")
        flash("Could not remove target; the details are in Jen's log.", "error")
    finally:
        if db:
            db.close()
    return redirect(url_for("watchdog.index"))


@bp.route("/targets/<int:target_id>/history")
@login_required
def target_history(target_id):
    row, _refusal = _load_target(target_id)
    if row is None:
        return jsonify({"error": "not found"}), 404
    db = None
    rows = []
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                "SELECT checked_at, ok, rtt_ms, error FROM wd_checks WHERE target_id=%s "
                "ORDER BY checked_at DESC LIMIT %s",
                (target_id, _HISTORY_LIMIT),
            )
            for r in cur.fetchall():
                rows.append(
                    {
                        "checked_at": r["checked_at"].strftime("%Y-%m-%d %H:%M") if r.get("checked_at") else "",
                        "ok": bool(r["ok"]),
                        "rtt_ms": r.get("rtt_ms"),
                        "error": r.get("error") or "",
                    }
                )
    except Exception as e:
        logger.error(f"Watchdog: history error: {e}")
    finally:
        if db:
            db.close()
    return jsonify({"rows": rows})


# ── Row action target: "Watch this host" (reservation rows) ───────────────────


@bp.route("/watch", methods=["POST"])
@login_required
@require_write(_VIEWER_MESSAGE, "watchdog.index")
def watch_from_row():
    ip = request.args.get("ip", "").strip()
    mac = _normalize_mac(request.args.get("mac", ""))
    hostname = request.args.get("hostname", "").strip()[:100]
    try:
        ipaddress.IPv4Address(ip)
    except ValueError:
        flash("Invalid IP address.", "error")
        return redirect(url_for("watchdog.index"))
    # The subnet is where the ADDRESS is, worked out here. The row action no longer sends a
    # `subnet_id` at all (v1.1.3: it was never read): what the page that linked us happened to know
    # is not what decides, because trusting it let a caller authorise against one subnet and watch a
    # host in another.
    subnet_id = derive_subnet_id(ip, _subnet_map())
    if not _can(subnet_id):
        flash(ADDRESS_REFUSAL, "error")
        return redirect(url_for("watchdog.index"))

    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute("SELECT id FROM wd_targets WHERE ip=%s", (ip,))
            if cur.fetchone():
                flash(f"{hostname or ip} is already being watched.", "warning")
                return redirect(url_for("watchdog.index"))
            cur.execute(
                "INSERT INTO wd_targets (ip, mac, subnet_id, label, source, probe, created_by) "
                "VALUES (%s, %s, %s, %s, 'reservation', 'ping', %s)",
                (ip, mac or None, subnet_id, hostname, current_user.username),
            )
        db.commit()
        flash(f"Now watching {hostname or ip}.", "success")
        _audit("WATCHDOG_ADD", ip, f"label={hostname} source=reservation")
    except Exception as e:
        logger.error(f"Watchdog: could not add target: {e}")
        flash("Could not add target; the details are in Jen's log.", "error")
    finally:
        if db:
            db.close()
    return redirect(url_for("watchdog.index"))


# ── JSON API (v1.0.0, plugin API v3) ───────────────────────────────────────────
# Undecorated on purpose: api_key_required() is applied in register(app), where each
# route is added to the blueprint.

api_bp = Blueprint("watchdog_api", __name__, url_prefix="/api/v1/plugins/watchdog")


def _api_list_targets():
    from flask import g

    from jen.plugin_api import api_key_can_access_subnet

    out = []
    for r in _target_rows():
        # a target in no subnet is for an unrestricted key only — a scoped key never gets it
        if not api_key_can_access_subnet(g.api_key, r["subnet_id"]):
            continue
        out.append(
            {
                "id": r["id"],
                "ip": r["ip"],
                "mac": r.get("mac") or "",
                "label": r.get("label") or "",
                "subnet_id": r["subnet_id"],
                "probe": r["probe"],
                "enabled": bool(r["enabled"]),
                "state": r.get("state") or "unknown",
                "uptime_pct": r.get("uptime_pct"),
            }
        )
    return jsonify({"targets": out})


def _api_add_target():
    from flask import g

    from jen.plugin_api import api_key_can_access_subnet, json_object_body, str_field

    body, bad_body = json_object_body()
    if bad_body:
        return bad_body
    ip = str_field(body, "ip")
    try:
        ipaddress.IPv4Address(ip)
    except ValueError:
        return jsonify({"error": "invalid ip"}), 400
    raw_mac = body.get("mac", "")
    if raw_mac and not isinstance(raw_mac, str):
        return jsonify({"error": "mac must be a string"}), 400
    probe = str_field(body, "probe") or "ping"
    kind, err = parse_probe(probe)
    if kind is None:
        return jsonify({"error": err}), 400
    subnet_id = derive_subnet_id(ip, _subnet_map())
    if not api_key_can_access_subnet(g.api_key, subnet_id):
        return jsonify({"error": "subnet not accessible to this key"}), 403
    label = str_field(body, "label", 100)
    mac = _normalize_mac(raw_mac)
    interval_min = body.get("interval_min", 5)
    fails_to_down = body.get("fails_to_down", 3)
    if interval_min not in _INTERVAL_CHOICES or fails_to_down not in _FAILS_CHOICES:
        return jsonify({"error": "invalid interval_min/fails_to_down"}), 400

    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            # v1.0.4 — the page's own Add Target form already refuses a second target for one IP; the
            # API did not.
            cur.execute("SELECT id FROM wd_targets WHERE ip=%s", (ip,))
            if cur.fetchone():
                return jsonify({"error": f"{ip} is already being watched"}), 409
            cur.execute(
                "INSERT INTO wd_targets (ip, mac, subnet_id, label, source, probe, interval_min, "
                "fails_to_down, created_by) VALUES (%s, %s, %s, %s, 'manual', %s, %s, %s, %s)",
                (ip, mac or None, subnet_id, label, probe, interval_min, fails_to_down, f"api:{g.api_key['name']}"),
            )
            new_id = cur.lastrowid
        db.commit()
    except Exception as e:
        logger.error(f"Watchdog: API request failed: {e}")
        return jsonify({"error": "internal error; the details are in the Jen log"}), 500
    finally:
        if db:
            db.close()
    return jsonify({"ok": True, "id": new_id, "ip": ip})


def register(app):
    app.register_blueprint(bp)

    from jen.plugin_api import (
        api_key_required,
        register_alert_type,
        register_investigation_provider,
        register_periodic,
        register_row_action,
        register_search_provider,
    )

    try:
        from jen.plugin_api import PERIODIC_MIN_MINUTES as _tick_every
    except ImportError:
        # Jen versions before PERIODIC_MIN_MINUTES was exported (v5.60.1) —
        # 5 is the actual floor there too, it just wasn't importable yet.
        _tick_every = 5

    api_bp.add_url_rule(
        "/targets", "api_list_targets", api_key_required(write=False)(_api_list_targets), methods=["GET"]
    )
    api_bp.add_url_rule("/targets", "api_add_target", api_key_required(write=True)(_api_add_target), methods=["POST"])
    app.register_blueprint(api_bp)

    register_alert_type(
        PLUGIN_ID,
        "watchdog_down",
        label="Watchdog: host down",
        icon="circle-x",
        default_template="🚨 <b>{label}</b> ({ip}, {subnet}) has stopped answering.",
    )
    register_alert_type(
        PLUGIN_ID,
        "watchdog_up",
        label="Watchdog: host back up",
        icon="circle-check",
        default_template="✅ <b>{label}</b> ({ip}, {subnet}) is answering again.",
    )
    register_row_action(
        PLUGIN_ID,
        "reservation",
        label="Watch this host",
        icon="activity",
        href="/network/watchdog/watch?mac={mac}&ip={ip}&hostname={hostname}",
        method="POST",
    )
    register_search_provider(PLUGIN_ID, title="Host Watchdog", fn=_watchdog_search)
    register_investigation_provider(PLUGIN_ID, title="Host Watchdog", fn=_investigate)
    register_periodic(PLUGIN_ID, "probe-tick", _tick, _tick_every)

    logger.info("Host Watchdog plugin registered")
